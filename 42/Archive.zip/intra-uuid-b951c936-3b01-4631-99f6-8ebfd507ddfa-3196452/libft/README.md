# libft
Remake of some functions included in standard C libs
